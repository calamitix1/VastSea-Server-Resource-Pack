STARDUST TOOLS ADD-ON — ORIGINAL BLUE PALETTE RESTORED

This is merged into the furniture-fixed VastSeas pack. The Minecraft carrier items remain Netherite tools (plus vanilla bow, crossbow, shield, and stick for staff), but the Stardust appearance now uses the source pack's original bright blue/cyan palette.

CUSTOM MODEL DATA: 2401.0 in minecraft:custom_model_data floats[0].

Commands:
/give @s minecraft:netherite_sword[minecraft:custom_model_data={floats:[2401.0]}] 1
/give @s minecraft:netherite_axe[minecraft:custom_model_data={floats:[2401.0]}] 1
/give @s minecraft:netherite_pickaxe[minecraft:custom_model_data={floats:[2401.0]}] 1
/give @s minecraft:netherite_shovel[minecraft:custom_model_data={floats:[2401.0]}] 1
/give @s minecraft:netherite_hoe[minecraft:custom_model_data={floats:[2401.0]}] 1
/give @s minecraft:bow[minecraft:custom_model_data={floats:[2401.0]}] 1
/give @s minecraft:crossbow[minecraft:custom_model_data={floats:[2401.0]}] 1
/give @s minecraft:shield[minecraft:custom_model_data={floats:[2401.0]}] 1
/give @s minecraft:stick[minecraft:custom_model_data={floats:[2401.0]}] 1  # Stardust staff

Palette details:
- Netherite tool carriers select the Stardust *_diamond model variants, which point to the original unsuffixed bright blue/cyan Stardust textures.
- Bow and crossbow draw/pull/charged states use matching *_diamond variants.
- Shield blocking uses the matching diamond_blocking model.
- No PNG files were recolored or modified; original source textures are preserved.
- Furniture, plushies, hats, glasses, Christmas content, atlas definitions, and all other pack files remain unchanged.
